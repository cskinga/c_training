#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>


//12.feladat
//void bekert_szam(char ertek[10])
//{
//    bool karakter = false;
//    bool tizedes = false;
//    bool hatvanykitevo = false;
//    char seged[10];
//    char seged2[10];
//    for (int i = 0; i < 10 && karakter != true; i++)
//    {
//        if (ertek[0] != '-' && ertek[i] != '.' && ertek[i] != 'e' && (ertek[i] < '0' || ertek[i] > '9'))
//        {
//            printf("nem egy szam!!");
//            karakter = true;
//        }
//        else if (ertek[i] == '.')
//        {
//            tizedes = true;
//        }
//        else if (ertek[i] == 'e')
//        {
//            seged2 = ertek.substr(0, i);
//            seged = ertek.substr(i + 1, ertek.length());
//            hatvanykitevo = true;
//        }
//    }
//    if (karakter == false)
//    {
//        if (hatvanykitevo == true)
//        {
//            printf( "%f",3 * stof(seged2) * pow(10, stof(seged)));
//        }
//        else if (tizedes == true)
//        {
//            printf("%f", 3 * stof(ertek));
//        }
//        else
//            printf("%f", 3 * stof(ertek));
//    }
//}

//15.feladat
char Nagybetusites()
{
    char szoveg[20];
    for(int i = 0; i < 20; i++)
    {
        scanf("%c", &szoveg[i]);
    }
    for(int i = 0; i < 20; i++)
    {
        if((i == 0 || szoveg[i - 1] == ' ') && (szoveg[i] >= 'a' && szoveg[i] <= 'z' ))
        {
            szoveg[i] = szoveg[i] + 'A' - 'a';
            printf("%c", szoveg[i]);
        }
    }

}

//18.feladat
char Nagy_es_kisbetuk_felcserelese()
{
    char szoveg[20];
    for(int i = 0; i < 20; i++)
    {
        scanf("%c", &szoveg[i]);
    }
    for(int i = 0; i < 20; i++)
    {
        if(szoveg[i] >= 'a' && szoveg[i] <= 'z' )
        {
            szoveg[i] = szoveg[i] + 'A' - 'a';
            printf("%c", szoveg[i]);
        }
        else if(szoveg[i] >= 'A' && szoveg[i] <= 'Z' )
        {
            szoveg[i] = szoveg[i] - 'A' + 'a';
            printf("%c", szoveg[i]);
        }
    }

}

//19.feladat
void szamok_fele_a_szamsorban()
{
    float szamsor[10];
    for(int i = 0; i < 10; i++)
    {
        scanf("%f", &szamsor[i]);
    }
    for(int j = 0; j < 10; j++)
    {
        szamsor[j] = szamsor[j] / 2;
        printf("%f\t", szamsor[j]);
    }

}

//20.feladat
void szamsor_megforditas()
{
    float szamsor[10];
    float seged[10];
    for(int i = 0; i < 10; i++)
    {
        scanf("%f", &szamsor[i]);
        seged[i] = szamsor[i];
    }
    for(int j = 0; j < 10; j++)
    {
        szamsor[j] = seged[9 - j];
        printf("%f\t", szamsor[j]);
    }
}

void szoveg_megforditas()
{
    char szoveg[20];
    char seged[20];
    for(int i = 0; i < 20; i++)
    {
        scanf("%c", &szoveg[i]);
        seged[i] = szoveg[i];
    }
    for(int j = 0; j < 20; j++)
    {
        szoveg[j] = seged[19 - j];
        printf("%c", szoveg[j]);
    }
}


int main()
{
//    bekert_szam("123");
//    printf("\n");
//    bekert_szam("-123");
//    printf("\n");
//    bekert_szam("123.23");
//    printf("\n");
//    bekert_szam("123.32e2.5");

//    printf("15.feladat:\n");
//    Nagybetusites();  //m�g kell rajta csiszolni.
//    printf("\n");
//
    printf("18.feladat:\n");
    Nagy_es_kisbetuk_felcserelese(); //m�g kell rajta csiszolni.
    printf("\n");

    printf("19.feladat:\n");
    szamok_fele_a_szamsorban();
    printf("\n");

    printf("20.feladat:\n");
    szamsor_megforditas();
    printf("\n");
    szoveg_megforditas();
    printf("\n\n");

}
