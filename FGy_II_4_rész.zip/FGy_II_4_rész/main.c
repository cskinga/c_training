#include <stdio.h>
#include <stdlib.h>


//13.feladat
void monogramm()
{
    char szoveg[30];
    int szamlalo = 30;
    for(int i = 0; i < 30; i++)
    {
        scanf("%c", &szoveg[i]);
        if(szoveg[i] == '\n')
        {
            szamlalo = i;
            break;
        }
    }
    for(int j = 0; j < szamlalo; j++)
    {
        if((j == 0 || szoveg[j - 1] == ' ') && (szoveg[j] >= 'a' && szoveg[j] <= 'z'))
        {
           szoveg[j] = szoveg[j] + 'A' - 'a';
           printf("%c", szoveg[j]);
        }
        else if((j == 0 || szoveg[j - 1] == ' ') && (szoveg[j] >= 'A' && szoveg[j] <= 'Z'))
        {
            printf("%c", szoveg[j]);
        }
        else if((j == 0 || szoveg[j - 1] == ' '))
        {
           printf("\n%c: Ez a karakter nem betu!\n", szoveg[j]);
        }
    }
}

//16.feladat
void szo_kivagas()
{
    char szoveg[30];
    char mit[10];
    int szamlalo1 = 30;
    int szamlalo2 = 10;
    for(int i = 0; i < 30; i++)
    {
        scanf("%c", &szoveg[i]);
        if(szoveg[i] == '\n')
        {
            szamlalo1 = i;
            break;
        }
    }
    for(int j = 0; j < 10; j++)
    {
        scanf("%c", &mit[j]);
        if(mit[j] == '\n')
        {
            szamlalo2 = j;
            break;
        }
    }
    for(int k = 0; k < szamlalo1; k++)
    {
        for(int l = 0; l < szamlalo2; l++)
        {
            if(mit[l] == szoveg[k])
            {
                k++;
            }
            else
            {
                k = k - l + 1;
                l = 0;
            }
            //ezt m�g be kell fejezni.
        }
    }

}


//22.feladat
void azonos_pozicio_e()
{
    char szoveg1[30];
    char szoveg2[30];
    int szamlalo1 = 30;
    int szamlalo2 = 30;
    for(int i = 0; i < 30; i++)
    {
        scanf("%c", &szoveg1[i]);
        if(szoveg1[i] == '\n')
        {
            szamlalo1 = i;
            break;
        }
    }
    for(int j = 0; j < 30; j++)
    {
        scanf("%c", &szoveg2[j]);
        if(szoveg2[j] == '\n')
        {
            szamlalo2 = j;
            break;
        }
    }
    for(int k = 0; k < szamlalo2; k++)
    {
        if(szoveg1[k] == szoveg2[k])
        {
            printf("%d ", k);
        }
    }
}

//25.feladat
void szovegbol_szavak()
{
    char szoveg[30];
    int szamlalo = 30;
    for(int i = 0; i < 30; i++)
    {
        scanf("%c", &szoveg[i]);
        if(szoveg[i] == '\n')
        {
            szamlalo = i;
            break;
        }
    }
    for(int j = 0; j < szamlalo; j++)
    {
        if(szoveg[j] == ' ')
        {
            szoveg[j] = '\n';
        }
        printf("%c", szoveg[j]);
    }
}

//28.feladat
void legnagyobb_paros_szam()
{
    char szoveg[30];
    int szamlalo = 30;
    int helyiertek = 0;
    for(int i = 0; i < 30; i++)
    {
        scanf("%c", &szoveg[i]);
        if(szoveg[i] == '\n')
        {
            szamlalo = i;
            break;
        }
    }
    for(int i = 0; i < szamlalo - 1; i++)
    {
        if(szoveg[i] >= '0' && szoveg[i] <= '9')
        {
            helyiertek += 1;
            if(szoveg[i + 1] < '0' && szoveg[i + 1] > '9')
            {
                if(szoveg[i] % 2 == 0)
                {

                }
            }
        }
    }
}

void novekvo_szamsor()
{
    int szamsor[10];
    int seged[10];
    int szamlalo = 10;
    for(int i = 0; i < szamlalo; i++)
    {
        scanf("%d", &szamsor[i]);
        seged[i] = szamsor[i];
    }
    for(int i = 1; i < szamlalo; i++)
    {
        if(szamsor[i - 1] > szamsor[i])
        {
            szamsor[i - 1] = seged[i];
            szamsor[i] = seged[i - 1];
            printf("%d %d", szamsor[i- 1], szamsor[i]);
        }
        else
            printf("%d ", szamsor[i]);
    }
}

int main()
{
//    printf("13.feladat:\n");
//    monogramm();
//    printf("\n");

//    printf("22.feladat:\n");
//    azonos_pozicio_e();
//    printf("\n");

//    printf("25.feladat:\n");
//    szovegbol_szavak();
//    printf("\n");

    novekvo_szamsor();

    return 0;
}
