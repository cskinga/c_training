#include <stdio.h>
#include <stdlib.h>


//24.feladat
char sorszamozas()
{
    char szoveg[50];
    char seged[50];
    int szamlalo = 50;
    int sor = 1;
    for(int i = 0; i < 50; i++)
    {
        scanf("%c", &szoveg[i]);
        seged[i] = szoveg[i];
        if(szoveg[i] == '\n' && szoveg[i - 1] == '\n')
        {
            szamlalo = i;
            break;
        }
    }
    for(int j = 0; j < szamlalo; j++)
    {
        if(szoveg[j] == '\n')
        {
            szamlalo += 2;
            for(int k = j; k < szamlalo; k++)
            {
                szoveg[k + 2] = seged[k];
            }
            szoveg[j + 1] = '0' + sor;
            szoveg[j + 2] = '.';
            sor++;
        }
        else if(j == 0)
        {
            szamlalo += 2;
            for(int k = j; k < szamlalo; k++)
            {
                szoveg[k + 2] = seged[k];
            }
            szoveg[j] = '0' + sor;
            szoveg[j + 1] = '.';
            sor++;
        }
        printf("%c", szoveg[j]);
    }

    return szoveg;
}

//29.feladat
float negyzetgyo_iteracio()
{
    int n;
    float x;
    printf("x erteke: ");
    scanf("%f", &x);
    printf("iteralasok szama: ");
    scanf("%d", &n);
    float a0 = 1;
    float an = 1;
    for(int i = 1; i <= n; i++)
    {
        an = 0.5 * (an + (x / an));
    }
    printf("%.2f", an);
}

//30.feladat
void szamsor()
{
    int szamsor[10];
    int seged[10];
    int szamlalo = 1;
    for(int i = 0; i < 10; i++)
    {
        scanf("%d", &szamsor[i]);
        seged[i] = szamsor[i];
        szamlalo++;
    }
    for(int j = 0; j < szamlalo - 1; j++)
    {
        for(int k = j + 1; k < szamlalo; k++)
        if(szamsor[j] > szamsor[k])
        {
            szamsor[j] = szamsor[k];
            szamsor[k] = seged[j];
            seged[j] = szamsor[j];
            seged[k] = szamsor[k];
        }
        printf("%d ", szamsor[j]);
    }
    printf("\n");
}

//31.feladat

void sakktabla()
{
    for(int i = 0; i < 8; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            if(i % 2 == 0)
            {
                printf("**  ");
            }
            else
            {
                printf("  **");
            }
        }
        printf("\n");
    }
    printf("\n");
}
void atlos_negyzet(double sor)
{
    for (int i = 0; i < sor; i++)
    {
        for (int j = 0; j < (sor / 2); j++)
        {
            if (i % 2 == 0)
            {
                printf("*   ");
            }
            else
            {
                if (j == 0)
                {
                    printf("  *");
                }
                else if (j <= ((sor / 2) - 1))
                {
                    printf("   *");
                }
            }
        }
        printf("\n");
    }
}

int main()
{
    printf("24.feladat:\n");
    sorszamozas();
    printf("\n\n");

    printf("29.feladat:\n");
    negyzetgyo_iteracio();
    printf("\n\n");

    printf("30.feladat:\n");
    szamsor();
    printf("\n");

    printf("31.feladat:\n");
    sakktabla();
    atlos_negyzet(4);
    printf("\n");

    return 0;
}


