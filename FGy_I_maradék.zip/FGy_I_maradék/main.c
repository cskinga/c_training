#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

//14.feladat
void kezdobetu_szokoz_e()
{
    char szoveg[20];
    scanf("%c", &szoveg);
    if(szoveg[0] == ' ')
    {
        printf("TRUE\n");
    }
    else
        printf("FALSE\n");
}

//15.feladat
void Nagybetuvel_kezdodik_e()
{
    char szoveg[20];
    scanf("%c", &szoveg);
    if(szoveg[0] >= 'A' && szoveg[0] <= 'Z')
    {
        printf("TRUE\n");
    }
    else
        printf("FALSE\n");
}

//16.feladat

int vege()
{
    char szoveg[20];
    int vege;
    int seged = 0;
    scanf("%c", &szoveg);
    for(int i = 0; i < 20; i++)
    {
        if(szoveg[i] == '\0')
            break;
        else
            seged = i;
    }
    vege = seged;
    return vege;
}

void Szamjegy_e_a_vege()
{
    char szoveg[20];
    scanf("%c", &szoveg);
    if(szoveg[vege()] >= '0' && szoveg[vege()] <= '9')
    {
        printf("TRUE\n");
    }
    else
        printf("FALSE\n");
}


//18.feladat
char szoveg_bekeres(char szoveg[20])
{
    scanf("%c", &szoveg);
    return szoveg[20];
}

void elso_ot_karakter_mgegyezik_e()
{
    char szoveg1[20], szoveg2[20];
    szoveg_bekeres(szoveg1);
    szoveg_bekeres(szoveg2);
    scanf("%c", &szoveg1);
    scanf("%c", &szoveg2);
    for(int i = 0; i < 5; i++)
    {
        if(szoveg1[i] != szoveg2[i])
        {
            printf("FALSE\n");
            break;
        }
        else if(i = 4)
        {
            printf("TRUE\n");
        }
    }
}

int main()
{
    printf("14.feladat:\n");
    kezdobetu_szokoz_e();
    printf("\n");

    printf("15.feladat:\n");
    Nagybetuvel_kezdodik_e();
    printf("\n");

//    printf("16.feladat:\n");
//    Szamjegy_e_a_vege();
//    printf("\n");
    printf("18.feladat:\n");
    elso_ot_karakter_mgegyezik_e();
    printf("\n");

    return 0;
}
