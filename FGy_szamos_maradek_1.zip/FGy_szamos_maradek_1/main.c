#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

void kozos_osztok();
void n_random_szam();
void masodfoku_egyenletek();
void pascal_haromszog_n_sora();
float szamsor_atlaga();
void atlagnal_kisebb();
int paros_szamok();
float negyzetgyok_osszeg();

int main()
{
    printf("III. 13.feladat:\n%f\n\n",negyzetgyok_osszeg());

    printf("II. 3.feladat: \n");
    kozos_osztok();
    printf("\n");


    printf("II. 6.feladat: \n");
    n_random_szam();
    printf("\n");

    printf("II. 9.feladat: \n");
    masodfoku_egyenletek();
    printf("\n");

    printf("II. 10.feladat: \n");
    pascal_haromszog_n_sora();
    printf("\n");

    printf("III. 9.feladat:\n%f\n\n", szamsor_atlaga());

    printf("III. 10.feladat: \n");
    atlagnal_kisebb();
    printf("\n");

    printf("III. 11.feladat:\n%d\n\n", paros_szamok());

    printf("III. 13.feladat:\n%f\n\n",negyzetgyok_osszeg());

    return 0;
}

//FGy II. 3.feladat
void kozos_osztok()
{
    int szam1;
    scanf("%d", &szam1);
    int szam2;
    scanf("%d", &szam2);
    for(int i = 1; i <= szam1; i++)
    {
        if(szam1 % i == 0 && szam2 % i == 0)
        {
            printf("%d, ", i);
        }
    }
}

//FGy II. 6.feladat
void n_random_szam()
{
    int n;
    scanf("%d", &n);
    srand(time(NULL));
    int r;
    for(int i = 0; i < n; i++)
    {
        r = rand();
        printf("%d, ", r);
    }
}

//FGy II. 9.feladat
void masodfoku_egyenletek()
{
    int a, b, c;
    float x1, x2;
    for(a = 1; a < 10; a++)
    {
        for(b = 0; b < 10; b++)
        {
            for(c = 0; c < 10; c++)
            {
                x1 = ((-b) + (sqrt(pow(b, 2) - (4 * a * c)))) / (2 * a);
                x2 = ((-b) - (sqrt(pow(b, 2) - (4 * a * c)))) / (2 * a);
                if(x1 == x2)
                {
                    printf("%dx^(2) + %dx + %d = 0\n", a, b, c);
                }
            }
        }
    }
}

//FGy II. 10.feladat
void pascal_haromszog_n_sora()
{
    int sorok_szama;
    scanf("%d", &sorok_szama);
    for (int i = 0; i < sorok_szama; i++)
    {
        for(int k = 0; k < (sorok_szama - i - 1); k++)
        {
            printf(" ");
        }
        int ertek = 1;
        for (int j = 0; j <= i; j++)
        {
            printf("%d ", ertek);
            ertek = ertek * (i - j) / (j + 1);
        }
        printf("\n");
    }
    printf("\n");
}

//FGy III. 9.feladat
float szamsor_atlaga()
{
    int n;
    scanf("%d", &n);
    int szam;
    float atlag = 0;
    for(int i = 0; i < n; i++)
    {
        scanf("%d", &szam);
        atlag = (atlag * (i + 0.0) + szam + 0.0) / (i + 1.0);
    }
    return atlag;
}

//FGy III. 10.feladat
void atlagnal_kisebb()
{
    int szamsor[10];
    float atlag = 0;
    int szamlalo = 0;
    for(int i = 0; i < 10; i++)
    {
        scanf("%d", &szamsor[i]);
        atlag = (atlag * (i + 0.0) + szamsor[i] + 0.0) / (i + 1.0);
    }
    for(int j = 0; j < 10; j++)
    {
        if(szamsor[j] < atlag)
        {
            szamlalo += 1;
        }
    }
    printf("%d\n", szamlalo);
}

//FGy III. 11.feladat
int paros_szamok()
{
    int n;
    scanf("%d", &n);
    int szam;
    int paros = 0;
    for(int i = 0; i < n; i++)
    {
        scanf("%d", &szam);
        if(szam % 2 == 0)
        {
            paros += 1;
        }
    }
    return paros;
}

//FGy III. 13.feladat
float negyzetgyok_osszeg()
{
    int n;
    scanf("%d", &n);
    int szam;
    float osszeg = 0;
    for(int i = 0; i < n; i++)
    {
        scanf("%d", &szam);
        osszeg = osszeg + sqrt(szam);
    }
    return osszeg;
}
