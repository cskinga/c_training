#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

//int legnagyobb_ugras();
bool novekvo();
bool prim_e(int);
int R_sugaron_belul_eso_pont(int);
void legtavolabbi_pont();
int kozos(int, int);
bool baratsagos(int, int);
void haromszog_magassagai();

int main()
{
//    printf("FGy. III. 15.feladat: ");
//    printf("%d\n\n", legnagyobb_ugras());


    printf("FGy. III. 17.feladat: ");
    printf("%d\n\n", novekvo());

    printf("FGy. III. 19.feladat: ");
    int szam2;
    printf("%d\n\n", prim_e(szam2));

    printf("FGy. III. 35.feladat: \n");
    int R;
    printf("\n%d\n\n", R_sugaron_belul_eso_pont(R));


    printf("FGy. III. 36.feladat: ");
    legtavolabbi_pont();
    printf("\n");

    printf("FGy. VI. 2.feladat: ");
    int a, b;
    printf("%d\n\n", kozos(a, b));

    printf("FGy. VI. 4.feladat: ");
    int c, d;
    printf("%d\n\n", baratsagos(c, d));

    printf("FGy. VI. 13.feladat: ");
    haromszog_magassagai();
    return 0;
}

//FGy. III. 15.feladat
//int legnagyobb_ugras()
//{
//    int n;
//    scanf("%d", &n);
//    int szam;
//    int elozo;
//    int d;
//    int maxugras = 0;
//    for(int i = 0; i < n; i++)
//    {
//        scanf("%d", &szam);
//        if(i = 0)
//        {
//            elozo = szam;
//        }
//        d = szam - elozo;
//        if(maxugras < d)
//        {
//            maxugras = d;
//        }
//        elozo = szam;
//    }
//    return maxugras;
//}



//FGy. III. 17.feladat
bool novekvo()
{
    int n;
    scanf("%d", &n);
    int szam;
    int elozo = 0;
    bool novekvo = true;
    for(int i = 0; i < n; i++)
    {
        scanf("%d", &szam);
        if(elozo <= szam)
        {
            elozo = szam;
        }
        else
        {
            novekvo = false;
            break;
        }
    }
    return novekvo;
}

//FGy. III. 19.feladat
bool prim_e(int szam)
{
    bool prim = true;
    scanf("%d", &szam);
    for(int i = 2; i < sqrt(szam); i++)
    {
        if(szam % i == 0)
        {
            prim = false;
            break;
        }
    }
    return prim;
}

//FGy. III. 35.feladat
int R_sugaron_belul_eso_pont(int R)
{
    scanf("%d", &R);
    int n;
    scanf("%d", &n);
    int p[3];
    int belul = 0;
    float tavolsag = 0;
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            scanf("%d", &p[j]);
            tavolsag += pow(p[j], 2);
        }
        tavolsag = sqrt(tavolsag);
        if(tavolsag < R + 0.0)
        {
            belul += 1;
        }
    }
    return belul;
}

//FGy. III. 36.feladat
void legtavolabbi_pont()
{
    int n;
    scanf("%d", &n);
    int p[3];
    int pmaxtav[3];
    float tavolsag = 0;
    float maxtavolsag = 0;
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            scanf("%d", &p[j]);
            tavolsag += pow(p[j], 2);
        }
        tavolsag = sqrt(tavolsag);
        if(maxtavolsag < tavolsag)
        {
            maxtavolsag = tavolsag;
            for(int k = 0; k < 3; k++)
            {
                pmaxtav[k] = p[k];
            }
        }
    }
    printf("a pont koordinatai:\n");
    for(int l = 0; l < 3; l++)
    {
        printf("%d,\t", p[l]);
    }
    printf("a tavolsaga az origotol: %f\n", maxtavolsag);
}

//FGy. VI. 2.feladat
int kozos(int a, int b)
{
    scanf("%d %d", &a, &b);
    int osztok = 0;
    for(int i = 1; i <= a; i++)
    {
        if(a % i == 0 && b % i == 0)
        {
            osztok += 1;
        }
    }
    return osztok;
}

//FGy. VI. 4.feladat
bool baratsagos(int a, int b)
{
    scanf("%d %d", &a, &b);
    int osztoosszega = 0;
    int osztoosszegb = 0;
    bool baratsagos = false;
    for(int i = 1; i < a; i++)
    {
        if(a % i == 0)
        {
            osztoosszega += i;
        }
    }
    for(int j = 1; j < b; j++)
    {
        if(b % j == 0)
        {
            osztoosszegb += j;
        }
    }
    if(osztoosszega == b && osztoosszegb == a)
    {
        baratsagos = true;
    }
    return baratsagos;
}

//FGy. VI. 13.feladat
void haromszog_magassagai()
{
    int a, b, c;
    float ma, mb, mc;
    for(int i = 0; i < 1; i++)
    {
        printf("a haromszog oldalai: \n");
        scanf("%d %d %d", &a, &b, &c);
        if(a >= b + c || b >= a + c || c >= a + b)
        {
            printf("Ez nem haomszog!\n");
            i--;
        }
    }
    ma = sqrt((a + b + c + 0.0) * (-a + b + c + 0.0) * (a - b + c + 0.0) * (a + b - c + 0.0))/(2.0 * a);
    mb = sqrt((a + b + c + 0.0) * (-a + b + c + 0.0) * (a - b + c + 0.0) * (a + b - c + 0.0))/(2.0 * b);
    mc = sqrt((a + b + c + 0.0) * (-a + b + c + 0.0) * (a - b + c + 0.0) * (a + b - c + 0.0))/(2.0 * c);
    printf("a magassagok:\nma: %f\nmb: %f\nmc: %f\n", ma, mb, mc);
}

