#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

void legkisebb_legnagyobb();
int atlagos_kulonbseg(int);
float skalaris_szorzat(int);
bool tokeletes(int);

int main()
{

//    printf("FGy. III. 12.feladat:\n");
//    legkisebb_legnagyobb();

//    int n;
//    scanf("%d", &n);
//    printf("%f", skalaris_szorzat(n));

//    printf("%d", atlagos_kulonbseg(n));

    printf("%d", tokeletes(n));

    return 0;
}

//FGy. II. 11.feladat
//void ismetlodes()
//{
//    int szamsor[10];
//    int ismetlodo[10];
//    for(int i = 0; i < 10; i++)
//    {
//        scanf("%d", &szamsor[i]);
//        for(int j = i; j > 0; j--)
//        {
//            if(szamsor[i] == szamsor[i - j + 1])
//            {
//
//            }
//        }
//    }
//}


//FGy III. 12.feladat
void legkisebb_legnagyobb()
{
    int n;
    printf("szamsor hossza: ");
    scanf("%d", &n);
    int szam;
    int min;
    int max;
    printf("szamsor elemei:\n");
    for(int i = 0; i < n; i++)
    {
        scanf("%d", &szam);
        if(i == 0)
        {
            min = szam;
            max = szam;
        }
        else
        {
            if(max < szam)
            {
                max = szam;
            }
            else if(min > szam)
            {
                min = szam;
            }
        }
    }
    printf("\nmin: %d\nmax: %d", min, max);
}

//FGy III. 14.feadat
float skalaris_szorzat(int n)
{
    float a, b;
    float hossz1 = 0;
    float hossz2 = 0;
    float szorzat;
    float szog, alfa, beta;
    for(int i = 0; i < n; i++)
    {
        scanf("%d %d", &a, &b);
        if(i == n - 1)
        {
            alfa = tan(a / hossz1);
            beta = tan(b / hossz2);
            szog = abs(alfa - beta);
        }
        hossz1 += pow(a, 2);
        hossz2 += pow(b, 2);
    }
    hossz1 = sqrt(hossz1);
    hossz2 = sqrt(hossz2);
    szorzat = hossz1 * hossz2 * cos(szog);
    return szorzat;
}

//FGy III. 16.feladat
//int atlagos_kulonbseg(int n)
//{
//    int szam;
//    int elozo;
//    int kulonbseg = 0;
//    float atlagos = 0;
//    for(int i = 0; i < n; i++)
//    {
//        scanf("%d", &szam);
//        if(i == 0)
//        {
//            elozo = szam;
//        }
//        kulonbseg = szam - elozo;
//        atlagos = ((atlagos * (i + 0.0)) + (kulonbseg + 0.0))/ (i + 1.0);
//    }
//    return atlagos;
//}

//FGy VI. 3.feladat
bool tokeletes(int a)
{
    int osztoosszeg = 0;
    bool tokeletes = false;
    for(int i = 1; i <= a / 2; i++)
    {
        if(a % i == 0)
        {
            osztoosszeg += i;
        }
        if(osztoosszeg == a)
        {
            tokeletes = true;
        }
    }
    return tokeletes;
}
